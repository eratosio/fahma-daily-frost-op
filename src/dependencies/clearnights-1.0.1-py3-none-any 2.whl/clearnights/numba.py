import numpy as np
from numba import njit, prange


@njit(parallel=True)
def rolling_median(arr, window_size):
    n_rows, n_cols = arr.shape
    out_cols = n_cols - window_size + 1
    result = np.empty((n_rows, out_cols))

    for i in prange(n_rows):
        for j in range(n_cols):
            window = arr[i, j : j + window_size].copy()
            result[i, j] = np.median(window)

    return result
