import os
import datetime
from datetime import timedelta

import astral
import numpy as np
import pandas as pd
import pytz
import timezonefinder
from astral.sun import sun
from typing import Optional, Literal

from .lst import MIN_VALID_LST_C, MAX_VALID_LST_C, kelvin_to_celsius


path = os.path.abspath(os.path.dirname(__file__))
CLOUD_MASK_NA = 255

# 250519 ngu197: adding helper functions as private methods so that they can 'apply' on the data frame
def _remove_median_hourly_rolling(lst_series):
    """
    Remove the mean of time series data on an hourly rolling window.
    
    Parameters:
    lst_series (pd.Series or pd.DataFrame): Time series data with a datetime index.
    
    Returns:
    pd.Series or pd.DataFrame: Data with the mean removed in an hourly rolling window.
    """
    if not isinstance(lst_series, (pd.Series, pd.DataFrame)):
        raise TypeError("Input data must be a pandas Series or DataFrame.")
    
    # Ensure the data index is a datetime index
    if not isinstance(lst_series.index, pd.DatetimeIndex):
        raise ValueError("The index of the data must be a DatetimeIndex.")
    
    # Apply the rolling median over an hourly window
    rolling_median = lst_series.rolling(center=True, window='1H', min_periods=3).median()
    
    # Subtract the rolling mean from the original data
    data_median_rm = lst_series - rolling_median
    data_median_rm_var = data_median_rm.abs().rolling(center=True, window='1H', min_periods=3).var()

    return data_median_rm_var

def _mask_last_hour(data):
    """
    
    Parameters:
    data (pd.Series or pd.DataFrame): Time series data with a datetime index.
    
    Returns:
    pd.Series or pd.DataFrame: Data with the mean removed in an hourly rolling window.
    """
    if not isinstance(data, (pd.Series, pd.DataFrame)):
        raise TypeError("Input data must be a pandas Series or DataFrame.")
    
    # Ensure the data index is a datetime index
    if not isinstance(data.index, pd.DatetimeIndex):
        raise ValueError("The index of the data must be a DatetimeIndex.")
    
    # Select data in the last 90/60/30 minus of the last data point. If the value is non-negative, adjust to below 0.1
    end_time= data.index[-1]
    last_hour= end_time - datetime.timedelta(hours = 1)
    
    data[(data.index >= last_hour) & (data.index <= end_time)] = True
    data[data.index < last_hour] = False
    return data

def _mask_first_hour(data):
    """
    
    
    Parameters:
    data (pd.Series or pd.DataFrame): Time series data with a datetime index.
    
    Returns:
    pd.Series or pd.DataFrame: Data with the mean removed in an hourly rolling window.
    """
    if not isinstance(data, (pd.Series, pd.DataFrame)):
        raise TypeError("Input data must be a pandas Series or DataFrame.")
    
    # Ensure the data index is a datetime index
    if not isinstance(data.index, pd.DatetimeIndex):
        raise ValueError("The index of the data must be a DatetimeIndex.")
    
    # Select data in the last 90/60/30 minus of the last data point. If the value is non-negative, adjust to below 0.1
    start_time= data.index[0]
    first_hour= start_time + datetime.timedelta(hours = 1)
    
    data[(data.index >= start_time) & (data.index <= first_hour)] = True
    data[data.index > first_hour] = False
    return data

def _last_3_hours(data):
    """
    Detect if a particular data point is within 2 hours before sunrise
    
    Parameters:
    data (pd.Series or pd.DataFrame): Time series data with a datetime index.
    
    Returns:
    pd.Series or pd.DataFrame: Data with the mean removed in an hourly rolling window.
    """
    if not isinstance(data, (pd.Series, pd.DataFrame)):
        raise TypeError("Input data must be a pandas Series or DataFrame.")
    
    # Ensure the data index is a datetime index
    if not isinstance(data.index, pd.DatetimeIndex):
        raise ValueError("The index of the data must be a DatetimeIndex.")
    
    end_time= data.index[-1]
    last_hour= end_time - datetime.timedelta(hours = 3)
    
    data[(data.index >= last_hour) & (data.index <= end_time)] = True
    data[data.index < last_hour] = False
    return data

def _rm_low_counts(ds):
    # Process on a nightly basis
    # Count the number of non-NA data points
    # If the night dataset is empty, move to the next. else
    # Remove anything less than -10
    # If there are fewer than 5 data points, set them to NA.

    stage1_remainder = np.sum(ds.notnull())
    #print(stage1_remainder)

    
    if stage1_remainder > 0:
        #Remove anything less than -10
        ds.loc[ds < -10] = np.nan
        stage1_recount = np.sum(ds.notnull())
        #print(stage1_recount)

        if stage1_recount <= 10:
            ds.loc[ds.notnull()] = np.nan
    return ds

def _intersection(lst1, lst2):
    lst3 = [value for value in lst1 if value in lst2]
    return lst3
    
def _rm_early_overnight_min_temp(ds):
     # count the number of non-null LST after stage 1
    stage1_remainder = np.sum(ds.lst_stage12.notnull())
    
    #print(stage1_remainder)
    #If the night dataset is not empty
    if stage1_remainder > 0:
        # if the min overnight temperature falls below 2 and outside 2 hours before sunrise
        overnight_min = np.argmin(ds.lst_stage12)
        
        if np.nanmin(ds.lst_stage12) <= 2 and ~ds.loc[ds.index[overnight_min]].in_last_3_hours:
            # Look into the segment from sunset to 2 hours before sunrise
            before_min = ds.index[0].time()
            after_min = ds.loc[~ds.in_last_3_hours].index[-1].time()

            # Select any value below zero to NA
            selected = _intersection(ds.between_time(before_min, after_min).index, ds.loc[ds.lst_stage12 <= 2].index)
            #print(ds.loc[selected])
            ds.loc[selected, 'lst_stage12'] = np.nan
            #print(ds.loc[selected])
            
        return ds
    return ds

class ClearNights:

    DEFAULT_SETTINGS = {
        'stage2_air_temp_diff_delta_threshold': 2.0,
        'stage2_type': 'disabled'
    }

    def __init__(self, settings: dict = None, tf_kwargs : dict = None):
        if settings is None:
            settings = {}
        if tf_kwargs is None:
            tf_kwargs = {}
        self._settings = ClearNights.DEFAULT_SETTINGS.copy()
        self._settings.update(settings)
        self.tf = timezonefinder.TimezoneFinder(**tf_kwargs)

    def process_location(
        self,
        lst: pd.DataFrame,
        tair: Optional[pd.DataFrame],
        longitude: float,
        latitude: float,
        compute_night: bool = True,
        compute_artefacts: bool = True,
        unit: Literal["K", "C"] = "K",
    ):
        """

        Returns ClearNights filtered version of noctural LST.

        :param lst: pd.DataFrame with a single column containing LST as a float in Kelvin
        :param tair: pd.DataFram with a single column containing air temperature as a float in degrees celcius
        :param longitude:
        :param latitude:
        :return:
        """
        processed_coords = np.array([[longitude, latitude]])

        if unit == "K":
            # convert Kelvin to Celsius
            lst.lst_original = lst.lst_original.apply(kelvin_to_celsius)

        # filter LST values below -23.15C or greater than 100C. these values are artefacts and therefore should be flagged to be excluded from the calculations
        if compute_artefacts:
            lst['artefact'] = np.where(np.logical_or(lst.lst_original.isnull(),
                                                     lst.lst_original <= MIN_VALID_LST_C,
                                                     lst.lst_original >= MAX_VALID_LST_C
                                                     ), 1, 0)
            lst['lst_original'] = np.where(lst.artefact == 0, lst.lst_original, np.nan)

        else:
            if 'artefact' not in lst:
                raise ValueError("Artefact column not in LST data")


        # _stage1_filter uses rolling, which will run into an error if indices are not monotonous
        # shouldn't be an issue with groupby
        if not lst.index.is_monotonic_increasing:
            lst = lst.sort_index()

        # 250519: Debug with Brendan up to here. the updated _stage1_filter ran without issues
        # BUT there is a formatting conflict in merging an object and datetime
        if compute_night:
            sun_info = self._sun_info(lst.index, processed_coords)
            lst['night'] = sun_info.night
        else:
            if 'night' not in lst:
                raise ValueError("Night column not in LST data")

        
        lst['lst_stage1'], lst['lst_stage1_mask'] = self._stage1_filter(lst)
        lst['lst_stage1_mask'] = lst['lst_stage1_mask'].fillna(CLOUD_MASK_NA).astype('uint8')
        if self._settings.get('stage2_type') != 'disabled':

            if tair is None:
                raise ValueError('tair must be provided to apply stage 2 filter')

            lst['lst_stage2'], lst['lst_stage2_mask'] = self._stage2_filter(lst.lst_stage1, tair)

        lst['artefact'] = lst['artefact'].astype('int')
        lst['night'] = lst['night'].astype('int')

        return lst


    def _sun_info_for_date(self, date, location_info):

        sun_info = astral.sun.sun(location_info.observer, date=date)
        date = pd.to_datetime(
            date, utc=True, errors='raise'
        )
        return pd.Series({'date': date,
                          'sunrise': sun_info['sunrise'],
                          'sunset': sun_info['sunset']
                          })

    def _get_local_daylight_info(self, processed_coords, day_index, approx_tz = True):


        # From the lat/long, get the tz-database-style time zone name (e.g. 'America/Vancouver') or None
        # SN: these timezone caclulations are redundant.
        if approx_tz:
            timezone_str = self.tf.timezone_at(lat=processed_coords[0][1], lng=processed_coords[0][0])
        else:
            timezone_str = self.tf.certain_timezone_at(lat=processed_coords[0][1], lng=processed_coords[0][0])

        location_info = astral.LocationInfo('site location', timezone_str.split("/")[0], timezone_str,
                                            processed_coords[0][1],
                                            processed_coords[0][0])
        
        sun_info = pd.Series(day_index).apply(self._sun_info_for_date, location_info=location_info)
        
        return sun_info

    def _sun_info(self, index: pd.Series, processed_coords):
        # Look up sunrise times
        unique_days = np.unique(index.date)

        sun_info = self._get_local_daylight_info(processed_coords, unique_days)

        df = pd.DataFrame({'UTC': index})
        df['date'] = df.UTC.dt.date

        if df['date'].dtype == 'object':
            try:
                df['date'] = pd.to_datetime(df['date'], utc=True)
                print(f"Converted column 'date' to datetime64[ns, UTC]")
            except Exception as e:
                print(f"Column 'date' could not be converted to datetime: {e}")

        df = pd.merge(df, sun_info, on='date', how='left')
        df.set_index('UTC', inplace=True)

        # Extent night time to one hour after sunrise to account for full extent of potential frosts
        df['night'] = df.apply(lambda r: r['sunset'].time() <= r.name.time() <= (r['sunrise'] + timedelta(hours=1)).time(), axis=1)

        return df

    def _stage1_filter(self, lst: pd.DataFrame):
        
        # Create a new column to contain the moving variance on moving median removed data
        # 
        lst.loc[:,'lst_median_rm'] = lst.lst_original

        ### For each day, calculate moving hourly median, remove it from the data, then calculate moving hourly variance
        ### But not filtering for nocturnal hours yet, the first and last few data points will not be NA
        lst.lst_median_rm = lst.lst_median_rm.groupby(lst.index.date, as_index=True).apply(_remove_median_hourly_rolling).droplevel(0)

        ### Now, separate the nocturnal hours to do more filtering
        lst_nocturnal = lst.loc[lst.night]

        # Create a new column to mark the first hour after sunrise
        lst_nocturnal.loc[:,'in_last_hour'] = False

        # Create a new column to mark the last three hours of the nocturnal time
        lst_nocturnal.loc[:,'in_last_3_hours'] = False

        # More filtering
        lst_nocturnal.in_last_hour = lst_nocturnal.in_last_hour.groupby(lst_nocturnal.index.date, as_index=True).apply(_mask_last_hour).droplevel(0)
        lst_nocturnal.in_last_3_hours = lst_nocturnal.in_last_3_hours.groupby(lst_nocturnal.index.date, as_index=True).apply(_last_3_hours).droplevel(0)

        # lst_nocturnal.loc[:,'lst_stage12'] = lst_nocturnal.lst_original

        # If these hours are more than an hour BEFORE sunrise, threshold is strict: 0.1
        lst_nocturnal.loc[:,'lst_stage12'] = lst_nocturnal.loc[np.logical_and(~lst_nocturnal.in_last_hour, lst_nocturnal.lst_median_rm < 0.1)].lst_original
        
        # If these hours are within an hour BEFORE sunrise, threshold is less strict to allow for the steep rise of temperature
        lst_nocturnal.loc[np.logical_and(np.logical_and(lst_nocturnal.in_last_hour, lst_nocturnal.lst_median_rm < 0.5), lst_nocturnal.lst_original > 0), 'lst_stage12'] = lst_nocturnal.loc[np.logical_and(np.logical_and(lst_nocturnal.in_last_hour, lst_nocturnal.lst_median_rm < 0.5), lst_nocturnal.lst_original > 0),'lst_original']

        # If the minimum overnight temperature occurs more than 2 hours before sunrise, that is likely a cloud
        lst_nocturnal.loc[:,'lst_stage1_cleaned'] = lst_nocturnal.loc[:,['lst_stage12', 'in_last_3_hours']].groupby(lst_nocturnal.index.date, as_index=True).apply(_rm_early_overnight_min_temp).droplevel(0)['lst_stage12']

        # If an hour of data has too few remaining due to previous filtering steps, the rest are not that trustworthy either
        lst_nocturnal.loc[:,'lst_stage1_updated'] = lst_nocturnal.lst_stage1_cleaned.groupby(lst_nocturnal.index.date, as_index=True).apply(_rm_low_counts).droplevel(0)

        # Merge results back in the original data frame 
        # by filling values from the nocturnal hours
        lst.loc[:,'lst_stage1_updated_mask'] = np.nan
        lst.loc[lst.night,'lst_stage1_updated_mask'] = lst_nocturnal.lst_stage1_updated.notnull()
        lst_stage1_mask = lst.lst_stage1_updated_mask

        lst.loc[:,'lst_stage1_updated'] = np.nan
        lst.loc[lst.night,'lst_stage1_updated'] = lst_nocturnal.lst_stage1_updated
        lst_filtered = lst.lst_stage1_updated

        return lst_filtered, lst_stage1_mask

    def _stage2_filter(self, lst_series: pd.Series, tair_series: pd.Series):

        # TODO: Complete implementation and validation of stage 2 filtering
        raise NotImplementedError('Stage 2 filtering not yet implemented')

        #TODO: Where do we validate air temp data. What are the constraints?
        # - hourly or faster
        # - continuous? or some threshold on missing data?
        # - 00:00 alignment?

        # # 1st order difference of air temp
        # # TODO: Question for Ha: Ha's code applies absolute function now rather than after aggregation.
        # tair_series['air_temp_diff'] = tair_series['air_temp'].diff()
        #
        # # Add the air temp to lst (10min) dataframe
        # merged = pd.DataFrame(lst_series).join(tair_series, how='left')
        #
        # # 1st order difference for LST
        # merged['lst_stage1_diff'] = merged['lst_stage1'].diff()
        #
        # # aggregate both 1st order difference streams to hourly, creating hourly frequency for both
        # # TODO: Is this tolerant to air temp not aligned to 00:00
        # # sum() creates the mean rate of change over the hour.
        # # NOTE: reample('h') will align timestamp with start of the hour
        # hourly = merged[['air_temp_diff', 'lst_stage1_diff']].resample('h').agg(pd.Series.sum, skipna=True, min_count=1)
        #
        # # absolute delta between air temp and lst derivatives
        # # Only interested in the absolute difference
        # hourly['air_temp_diff_delta'] = (hourly['air_temp_diff'] - hourly['lst_stage1_diff']).abs()
        #
        # # Thresholding of delta of LST and air temp derivatives
        # delta_threshold = self._settings.get('stage2_air_temp_diff_delta_threshold')
        # hourly['stage2_mask'] = hourly['air_temp_diff_delta'] < delta_threshold # TODO: value for this threshold??
        #
        # # merge mask back with the lst series, stage 2 masks out hourly blocks
        # final_merged = pd.merge_asof(lst_series, hourly['stage2_mask'], left_index=True, right_index=True, direction='forward', tolerance=timedelta(hours=1))
        #
        # lst_stage2 = lst_series.where(final_merged['stage2_mask'])
        #
        # return lst_stage2, final_merged['stage2_mask']
