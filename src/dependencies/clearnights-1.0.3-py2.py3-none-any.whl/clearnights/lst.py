
KELVIN_CELSIUS_OFFSET = 273.15

MIN_VALID_LST_C = -23.15
MAX_VALID_LST_C = 100


def kelvin_to_celsius(v):
    return v - KELVIN_CELSIUS_OFFSET

def celsius_to_kelvin(v):
    return v + KELVIN_CELSIUS_OFFSET

MAX_VALID_LST_K = celsius_to_kelvin(MAX_VALID_LST_C)
MIN_VALID_LST_K = celsius_to_kelvin(MIN_VALID_LST_C)
