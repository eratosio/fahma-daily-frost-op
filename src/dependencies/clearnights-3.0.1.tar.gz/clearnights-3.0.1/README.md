# ClearNights

A python module which implements the ClearNights algorithm developed by Dr. Ha Nguyen et. al.

## Installation

`pip install .` can be used to install the module to a Python environment after cloning this repository or alternatively `pip install git+git@github.com:csiro/fah-clearnights.git`. For development purposes, `hatch` can be used in order to quickly set up a virtual environment with all the necessary dependencies.

```bash
pip install hatch # if not already available
hatch env create
source .venv/bin/activate
```

# Usage

```python
from clearnights.clearnights import ClearNights

lst: pd.DataFrame = load_your_lst_data()
latitude = ...
longitude = ...

clearnights = ClearNights()

output_df = clearnights.process_location(lst, None, longitude, latitude)
```
