import pytest
import os
import pandas as pd
import xarray as xr
from itertools import product
from pathlib import Path
from clearnights.clearnights import ClearNights, CLOUD_MASK_NA
from clearnights.xarray import clearnights_preprocess


RESOURCE_PATH = Path(__file__).parent / "data"
TEST_CASE_PATH = RESOURCE_PATH / "cases"
OUTPUT_DATA = Path(__file__).parent / "output"
os.makedirs(OUTPUT_DATA, exist_ok=True)

def area_extents_table():
    df = pd.read_csv(RESOURCE_PATH / "reference_sites2.csv")
    test_data = (
        df[["name", "xcentroid", "ycentroid"]].set_index("name").to_dict("index")
    )
    return test_data


TEST_DATA = area_extents_table()
TEST_LOCATION_NAMES = list(TEST_DATA.keys())
TEST_DATES = [("2024-08-01", "2024-08-31"), ("2024-11-01", "2024-11-30")]

@pytest.fixture
def clearnights_processor():
    return ClearNights(settings={}, tf_kwargs={"in_memory": True})


def process_clearnights_per_group(group, clearnights):
    latitude = group.name[0]
    longitude = group.name[1]
    input_df = group.reset_index().drop(columns=["lat", "lon"]).set_index("time")
    df = clearnights.process_location(
        input_df,
        None,
        longitude,
        latitude,
        compute_night=False,
        compute_artefacts=False,
        unit="C",
    )
    return df[["lst_stage1_mask", "night", "artefact"]].astype("uint8")


def process_clearnights_xarray(
    dataset: xr.Dataset, clearnights: ClearNights
) -> xr.Dataset:

    clearnights_df = (
        dataset.rename({"lst": "lst_original"})
        .pipe(clearnights_preprocess)
        .to_dataframe()
        .groupby(["lat", "lon"])
        .apply(lambda x: process_clearnights_per_group(x, clearnights))
    )

    clearnights_gridded = xr.Dataset.from_dataframe(
        clearnights_df[["lst_stage1_mask", "night", "artefact"]]
    )
    clearnights_gridded.attrs["crs"] = "EPSG:4326"
    return clearnights_gridded

@pytest.mark.parametrize(
    ["name", "start_date", "end_date"],
    [
        (name,) + date_range
        for name, date_range in product(TEST_LOCATION_NAMES, TEST_DATES)
    ],
)

def test_csiro_cases(name, start_date, end_date):
    """
    Run test cases as defined in resources/cases/test_area_extents.csv
    """
    lon = TEST_DATA[name]["xcentroid"]
    lat = TEST_DATA[name]["ycentroid"]

    clearnights = ClearNights({}, tf_kwargs={"in_memory": True})

    lst_path = RESOURCE_PATH / "eratos_lst_reference_sites"
    lst_file = f"{name}-{start_date}-{end_date}_lst.nc"
    himawari = xr.load_dataset(lst_path / lst_file)
    cn = process_clearnights_xarray(himawari, clearnights)

    merged = himawari.merge(cn)

    # apply mask
    # xarray.DataArray.where masks out locations where the condition is FALSE
    merged = merged.assign(
        lst_masked=merged["lst"].where(~merged["lst_stage1_mask"] == 1, -999)
    )
    df = (
        merged.to_dataframe()
        .reset_index()
        .drop(columns=["lat", "lon"])
        .rename(columns={"lst": "lst_original"})
    )
    os.makedirs(OUTPUT_DATA / "reference_sites", exist_ok=True)
    df.to_csv(OUTPUT_DATA / "reference_sites" / f"{name}-{start_date}-{end_date}_lstcn.csv")

    # TODO - verify data
