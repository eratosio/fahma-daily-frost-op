from eratos.resource import Resource
from eratos.operator import operator
from clearnights_at_point import clearnights_at_point 
from typing import Union

@operator('ern:e-pn.io:resource:fahma.operators.clearnights.at.point')
def entry(
        context,
        start_date: str,
        end_date: str,
        geom : Union[str, Resource] = None,
        lat: float = None,
        lon: float = None,
        size: float = None
    ):
    eadapter = context['adapter']
    ecreds = eadapter._tracker_exchange._creds

    return clearnights_at_point(
        start_date,
        end_date,
        geom = geom,
        lat = lat,
        lon = lon,
        size = size,
        ecreds = ecreds
    )
    