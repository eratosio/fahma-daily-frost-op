# Eratos APSIM

## Directory Structure

```
lib/
src/
├─ clearnights_on_demand/
│  ├─ data/
│  ├─ eratos/
│  │  ├─ op.yaml
│  │  ├─ block_descriptor.yaml
│  ├─ entry.py
│  ├─ senaps_wrapper.py
│  ├─ ...
```

The code lives under `src/apsim`. `src/apsim/eratos` contains the Eratos related data used to generate resources on the Eratos platform. `lib/` contains any submodules which will be added to the model during deployment.

## Deployment

### Setup

Install requirements via

```sh
pip install -r requirements.txt
```

Set the following environment variables. NOTE THAT THE FAHMA CREDENTIALS SHOULD BE USED.

```sh
export SENAPS_KEY="your_senaps_api_key"
export ERATOS_ID="your_eratos_id"
export ERATOS_SECRET="your_eratos_secret"
```

### Running `build.py`

This has a variety of commands to update the Eratos operator/block, the Senaps model, etc. To update the model code, run

```sh
python build.py build
python build.py push_senaps
```

To update the Eratos block, e.g to change the description on the model card, edit the files under `/src/apsim/eratos`, then run

```sh
python build.py push_eratos
```

which will update the model on the Eratos side.

To add the model to an Eratos space, run

```sh
python build.py add_to <ERN>
```
