try:
    import xarray as xr
except ImportError:
    raise ImportError(
        "Xarray not installed, try installing clearnights with [xarray] optional dependency."
    )

import numpy as np
import pandas as pd
import astral
import datetime


def get_night_indicator(dataset: xr.Dataset) -> np.ndarray:
    dims = dataset.dims
    times = dataset["time"].values
    days = np.unique(times.astype("datetime64[D]"))
    nday = len(days)
    night = np.zeros(shape=(dims["time"], dims["lat"], dims["lon"]), dtype=bool)
    for i, x in enumerate(dataset.lon):
        for j, y in enumerate(dataset.lat):
            if nday > 1:
                for t in range(len(days) - 1):  # Need next day's sunrise
                    day = days[t].astype("O")  # Python datetime.date

                    sun_today = astral.sun.sun(
                        astral.Observer(latitude=y, longitude=x), date=day
                    )

                    # Get datetime64[ns] for comparisons
                    start = np.datetime64(
                        sun_today["sunset"] + datetime.timedelta(hours=1)
                    )
                    end = np.datetime64(sun_today["sunrise"])

                    # Use searchsorted for fast range indexing (binary search)
                    start_idx = np.searchsorted(times, start)
                    end_idx = np.searchsorted(times, end, side="right")

                    # Mark time[start_idx:end_idx] as night
                    night[start_idx:end_idx, j, i] = True
            else:
                suninfo = astral.sun.sun(
                    astral.Observer(latitude=y, longitude=x), date=days[0].astype("O")
                )
                night[:, j, i] = (
                    dataset.time
                    >= np.datetime64(suninfo["sunset"] + datetime.timedelta(hours=1))
                ) & (dataset.time <= np.datetime64(suninfo["sunrise"]))

    return night


def clearnights_preprocess(dataset: xr.Dataset) -> xr.Dataset:
    return dataset.assign(
        artefact=(
            dataset.lst_original.dims,
            np.where(
                (dataset.lst_original <= 250) | (np.isnan(dataset.lst_original)), 1, 0
            ).astype(bool),
        ),
        lst=dataset.lst_original - 273.15,
        night=(dataset.lst_original.dims, get_night_indicator(dataset)),
    )
