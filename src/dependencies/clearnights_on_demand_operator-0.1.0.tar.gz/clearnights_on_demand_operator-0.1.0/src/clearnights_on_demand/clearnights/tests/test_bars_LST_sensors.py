

# TODO: Implement BARS sensor validation