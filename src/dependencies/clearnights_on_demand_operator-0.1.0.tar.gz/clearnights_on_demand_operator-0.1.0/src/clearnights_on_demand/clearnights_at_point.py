import os

import xarray as xr
import numpy as np
import datetime
import logging
import json
import dask.dataframe as dd
import shapely as shp
import tempfile
from eratos.creds import AccessTokenCreds, BaseCreds
from eratos.adapter import Adapter
from eratos.resource import Resource
from eratos.dsutil.netcdf import gridded_geotime_netcdf_props
from shapely import Polygon
from clearnights.clearnights import ClearNights, CLOUD_MASK_NA
from clearnights.xarray import clearnights_preprocess
from typing import Dict, Union
from concurrent.futures import ThreadPoolExecutor
from geopy.distance import distance
from geopy.point import Point
from pyproj import Geod
from typing import Optional


from geopy.distance import distance
from geopy.point import Point
from pyproj import Geod
from typing import Optional


def generate_square(lat, lon, size_km):
    # The input is the center of the square (latitude, longitude)
    center_point = Point(lat, lon)

    # Calculate the four corners of the square
    # Half of the size in kilometers
    half_size = size_km / 2

    # North-West corner
    nw_corner = distance(kilometers=half_size).destination(
        center_point, 315
    )  # Bearing 315° is NW

    # North-East corner
    ne_corner = distance(kilometers=half_size).destination(
        center_point, 45
    )  # Bearing 45° is NE

    # South-East corner
    se_corner = distance(kilometers=half_size).destination(
        center_point, 135
    )  # Bearing 135° is SE

    # South-West corner
    sw_corner = distance(kilometers=half_size).destination(
        center_point, 225
    )  # Bearing 225° is SW

    return shp.Polygon(
        (
            (nw_corner.longitude, nw_corner.latitude),
            (ne_corner.longitude, ne_corner.latitude),
            (se_corner.longitude, se_corner.latitude),
            (sw_corner.longitude, sw_corner.latitude),
            (nw_corner.longitude, nw_corner.latitude),
        )
    )


def load_himawari_datasets(
    start_date: str,
    end_date: str,
    ecreds: BaseCreds,
    lat: Optional[float] = None,
    lon: Optional[float] = None,
    lat_min: Optional[float] = None,
    lat_max: Optional[float] = None,
    lon_min: Optional[float] = None,
    lon_max: Optional[float] = None,
) -> xr.Dataset:
    logger = logging.getLogger()
    lst_ern = "ern:e-pn.io:resource:csiro.blocks.himawari.lst.2km.24hr.{year}"
    start_year = datetime.datetime.strptime(start_date, "%Y-%m-%d").year
    end_year = datetime.datetime.strptime(end_date, "%Y-%m-%d").year

    logger.info(
        "Reading in Himawari Satellite Data for years %d - %d", start_year, end_year
    )
    at_point = lat_min is None or lon_min is None or lat_max is None or lon_max is None

    if at_point:
        logger.info(
            f"Slicing data to point lat: {lat}, lon: {lon} time: {start_date} - {end_date}"
        )
        datasets = [
            (
                xr.open_dataset(
                    lst_ern.format(year=year), engine="eratos", eratos_auth=ecreds
                )
                .sel(lat=[lat], lon=[lon], method="nearest")
                .sel(time=slice(start_date, end_date))
            )
            for year in range(start_year, end_year + 1)
        ]
    else:
        logger.info(
            f"Slicing data to bbox lat: ({lat_min}, {lat_max}), lon: ({lon_min}, {lon_max}) time: {start_date} - {end_date}"
        )
        datasets = [
            (
                xr.open_dataset(
                    lst_ern.format(year=year), engine="eratos", eratos_auth=ecreds
                ).sel(
                    lat=slice(lat_min, lat_max),
                    lon=slice(lon_min, lon_max),
                    time=slice(start_date, end_date),
                )
            )
            for year in range(start_year, end_year + 1)
        ]

    with ThreadPoolExecutor() as executor:
        datasets = list(executor.map(lambda x: x.load(), datasets))

    return xr.concat(datasets, dim="time") if len(datasets) > 1 else datasets[0]


def process_clearnights_per_group(group, clearnights):
    latitude = group.name[0]
    longitude = group.name[1]
    input_df = group.reset_index().drop(columns=["lat", "lon"]).set_index("time")
    df = clearnights.process_location(
        input_df,
        None,
        longitude,
        latitude,
        compute_night=False,
        compute_artefacts=False,
        unit="C",
    )
    return df[["lst_stage1_mask", "night", "artefact"]].astype("uint8")


def run_clearnights(dataset, clearnights):
    return (
        dataset.pipe(clearnights_preprocess)
        .to_dataframe()
        .rename(columns={"lst": "lst_original"})
        .pipe(lambda x: dd.from_pandas(x, npartitions=os.cpu_count() // 2))
        .groupby(["lat", "lon"])
        .apply(lambda x: process_clearnights_per_group(x, clearnights))
        .compute()
        .pipe(
            lambda x: xr.Dataset.from_dataframe(
                x[["lst_stage1_mask", "night", "artefact"]]
            )
        )
    )


def process_clearnights_xarray(
    dataset: xr.Dataset, clearnights: ClearNights
) -> xr.Dataset:
    logger = logging.getLogger()
    logger.info("Applying Clearnights to filtered data")

    clearnights_df = (
        dataset.rename({"lst": "lst_original"})
        .pipe(clearnights_preprocess)
        .to_dataframe()
        .groupby(["lat", "lon"])
        .apply(lambda x: process_clearnights_per_group(x, clearnights))
    )

    clearnights_gridded = xr.Dataset.from_dataframe(
        clearnights_df[["lst_stage1_mask", "night", "artefact"]]
    )
    clearnights_gridded.attrs["crs"] = "EPSG:4326"
    return clearnights_gridded


def clearnights_at_point(
    start_date: str,
    end_date: str,
    geom: Union[str, Resource] = None,
    lat: Optional[float] = None,
    lon: Optional[float] = None,
    size: Optional[float] = None,
    clearnights_kwargs: dict = None,
    secrets: Dict[str, str] = None,
    ecreds: BaseCreds = None,
) -> Dict[str, Resource]:
    """Generates Clearnights

    Parameters
    ----------
    secrets : Dict[str,str]
        _description_
    geom : Union[str, shp.Polygon]
        Polygon as shapely Polygon object or Eratos geom Resource
    lat : float
        _description_
    lon : float
        _description_
    size : float
        _description_
    start_date : str
        _description_
    end_date : str
        _description_
    clearnights_kwargs : dict, optional
        _description_, by default None
    ern : str, optional
        ERN to push block to
    Returns
    -------
    Dict[str,str]
        _description_
    """
    logger = logging.getLogger()
    at_point = False
    if lat is not None and lon is not None:
        if size is None or size == 0:
            at_point = True
            lon_min = None
            lat_min = None
            lon_max = None
            lat_max = None
        else:
            assert (lat > -44) and (lat < -10), (
                "Latitude must be between -10 and -44 degrees"
            )
            assert (lon > 112) and (lon < 155), (
                "Longitude must be between 112 and 155 degrees"
            )
            assert size >= 5, "Size must be greater than 5km2"
            poly = generate_square(lat, lon, np.sqrt(2 * size))
            lon_min, lat_min, lon_max, lat_max = poly.bounds

    elif geom is not None:
        if type(geom) is str:
            poly = shp.from_wkt(geom)
        elif type(geom) is Resource:
            poly = geom.get_geo()

        if not isinstance(poly, Polygon):
            raise ValueError(f"Geometry should be a single polygon, not a {type(poly)}")

        bbox = poly.envelope
        geod = Geod(ellps="WGS84")
        size = abs(geod.geometry_area_perimeter(bbox)[0]) / 1e6

        if size <= 5:
            mid_lat = poly.centroid.y
            mid_lon = poly.centroid.x
            logger.info("Small polygon detected, using square of 10km2")
            poly_new = generate_square(mid_lat, mid_lon, np.sqrt(2 * 10))
            assert poly_new

        lon_min, lat_min, lon_max, lat_max = poly.bounds

    else:
        raise ValueError(
            "Either geometry or (lat, lon) with optional size must be specified"
        )

    if secrets is not None:
        ecreds = AccessTokenCreds(**secrets)

    if ecreds is None:
        raise ValueError("Creds must be specified")

    eadapter = Adapter(ecreds)

    if not clearnights_kwargs:
        clearnights_kwargs = {}
    clearnights = ClearNights(clearnights_kwargs, tf_kwargs={"in_memory": True})

    himawari_data = load_himawari_datasets(
        start_date,
        end_date,
        ecreds,
        lat=lat,
        lon=lon,
        lat_min=lat_min,
        lat_max=lat_max,
        lon_min=lon_min,
        lon_max=lon_max,
    )

    with tempfile.TemporaryDirectory() as output_dir:
        fpath = os.path.join(output_dir, "clearnights.nc")
        clearnights_gridded_data = process_clearnights_xarray(
            himawari_data, clearnights
        )
        clearnights_gridded_data.to_netcdf(
            fpath,
            encoding={
                "lst_stage1_mask": {
                    "zlib": True,
                    "complevel": 8,
                    "fletcher32": True,
                    "_FillValue": CLOUD_MASK_NA,
                },
                "night": {"zlib": True, "complevel": 8, "fletcher32": True},
                "artefact": {"zlib": True, "complevel": 8, "fletcher32": True},
            },
            engine="h5netcdf",
        )

        logger.info("Creating Eratos resource")
        resource = eadapter.Resource(
            content={
                "@type": "ern:e-pn.io:schema:dataset",
                "type": "ern:e-pn.io:resource:eratos.dataset.type.gridded",
                "name": "Clearnights Gridded Test",
                "description": f"Clearnights data over a point ({lat}, {lon}) for the period {start_date} to {end_date}",
                "updateSchedule": "ern:e-pn.io:resource:eratos.schedule.noupdate",
                "file": "clearnights.nc",
            }
        )

        resource.save()
        filesmap = {"clearnnights.nc": fpath}

        props = gridded_geotime_netcdf_props(filesmap)
        logger.info("Pushing gridded dataset to Eratos")
        resource.data().push_objects(
            "ern::node:au-1.e-gn.io",
            objects=filesmap,
            connector="Objects:Gridded:v1",
            connectorProps=props,
        )

        logger.info(
            "Resulting resource manifest - \n %s",
            json.dumps(json.loads(resource.json()), indent=4),
        )

        return {"clearnights_gridded": resource}