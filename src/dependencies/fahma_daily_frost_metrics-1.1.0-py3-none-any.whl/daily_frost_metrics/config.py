from pydantic import BaseModel, Field


class FrostMetricsDailyConfig(BaseModel):
    start_date: str = Field(
        ..., description="Start date. Do not prcess any further back than this date."
    )
    target_date: str | None = Field(None, description="Target date. This defines the latest date to process. Defaults to today")
    replace_outdated: bool = Field(
        ...,
        description="Whether to replace outdated files based on mismatch in version number/file",
    )
    process_missing_days: bool = Field(
        True, description="Whether to process missing dates"
    )
    spaces: list[str] = Field(..., description="List of space ERNS")
    frost_threshold_lst: list[int] = Field(..., description="Frost hours temperature threshold")
    duration_threshold_lst: list[int] = Field(..., description="Frost Duration temperature threshold")
