import copy
import logging
import os
import tempfile
import warnings
from datetime import datetime
from pathlib import Path
from typing import Dict
from typing import Optional

import eratos
import numpy as np
import xarray as xr
from dask.distributed import LocalCluster
from distributed.system import memory_limit
from eratos import creds
from eratos.adapter import Adapter
from eratos.data import Data
from eratos.dsutil.netcdf import gridded_geotime_netcdf_props
from xarray import Dataset

from .config import FrostMetricsDailyConfig
from .util import LSTCNFetcher, default_cf_encodings, get_missing_days, matching_pairs, extract_date, \
    FakeTempDir, get_year_ranges
from .version import get_version

warnings.filterwarnings("ignore")

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] [%(module)s] : %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)
logger = logging.getLogger()

_DEFAULT_FILL_VALUE = np.finfo(np.float32).max


def fetch_data_from_ern(
        ern: str, adapter: Adapter) -> tuple:
    resource = adapter.Resource(ern)
    lst_data = resource.data()
    logger.debug("Fetching files")
    lst_files = list(lst_data.list_objects())

    return lst_files, lst_data


def get_masked_lst(
        lst_chunk: xr.Dataset,
        mask_chunk: xr.Dataset,
):


    night = mask_chunk['night']
    night_data = night.data.astype(np.uint8)  # shape: (time, lat, lon)

    mask_chunk['lst_stage1_mask'] = mask_chunk['lst_stage1_mask'].where(mask_chunk['lst_stage1_mask'] == 1, np.nan)
    combined_mask = night_data * mask_chunk['lst_stage1_mask']
    combined_mask = combined_mask.assign_coords(time=lst_chunk['time'])
    masked_lst = lst_chunk.where(combined_mask == 1, np.nan)
    logger.info(f"Masked LST: {masked_lst}")
    KELVIN_TO_CELSIUS = -273.15
    masked_lst = masked_lst + KELVIN_TO_CELSIUS  # Convert to Celsius

    return masked_lst


def process_min_temp(
        masked_lst: xr.Dataset) -> xr.Dataset:
    if bool(masked_lst["lst"].isnull().all()) or bool(masked_lst['time'].isnull().all()):
        logger.info("Found masked LST which all values are NaN")
        logger.info(
            "Found masked LST which time dimension is None, potentially caused by date mismatch between LST and CN files")

        return None
    logger.info("Processing Minimum Temperature")
    min_temp = masked_lst.groupby(masked_lst.time.dt.date).min(dim='time')
    min_temp['date'] = min_temp['date'].astype('datetime64[ns]')
    min_temp = min_temp.rename({"lst": "min_temp", 'date': 'time'})

    return min_temp


def get_min_temp(
        config: FrostMetricsDailyConfig,
        output_dir: str,
        lst_cn_fetcher: LSTCNFetcher,
        cn_data: Data,
        lst_data: Data,
        cn_file: str,
        lst_file: str,
):
    origin_time = extract_date(lst_file)
    origin_time_str = origin_time.strftime('%Y-%m-%d')
    fname = f"daily_min_temp_{origin_time_str}_v{get_version()}.nc"
    min_temp_path = os.path.join(output_dir, fname)
    if os.path.exists(min_temp_path):
        return min_temp_path, fname

    ds_lst, ds_cn = lst_cn_fetcher.fetch_lst_cn_pair(
        cn_data, lst_data, cn_file, lst_file, xarray=True
    )
    masked_lst = get_masked_lst(ds_lst, ds_cn)

    min_temp = process_min_temp(masked_lst)

    if min_temp is None:
        logger.info(f"Skipping pair {cn_file}, {lst_file} due to timestamp mismatch")
        return None
    try:
        min_temp.load()
        encoding = default_cf_encodings(origin_time)
        encoding.update({
            'min_temp': {'dtype': 'float32', 'zlib': True, 'complevel': 4, "_FillValue": _DEFAULT_FILL_VALUE}
        })
        min_temp.to_netcdf(min_temp_path, engine="h5netcdf", encoding=encoding)
        return min_temp_path, fname
    except OSError as e:
        logger.error(
            f"[OSError] File system error while handling min_temp.nc, {origin_time_str}:\n{e}")
        raise
    except ValueError as e:
        logger.error(
            f"[ValueError] Data formatting or encoding error while handling min_temp.nc, {origin_time_str}:\n{e}")
        raise
    except TypeError as e:
        logger.error(
            f"[TypeError] Possibly invalid dtype or encoding structure for min_temp.nc: {e}")
        raise


def get_frost_hours(
        config: FrostMetricsDailyConfig,
        output_dir: str,
        lst_cn_fetcher: LSTCNFetcher,
        cn_data: Data,
        lst_data: Data,
        cn_file: str,
        lst_file: str,
        frost_threshold: float,
        duration_threshold: float,
):
    origin_time = extract_date(lst_file)
    origin_time_str = origin_time.strftime('%Y-%m-%d')
    weighted_frost_fname = f"daily_frost_hours_{origin_time_str}_v{get_version()}.nc"
    weighted_frost_path = os.path.join(output_dir, weighted_frost_fname)
    duration_fname = f"daily_duration_{origin_time_str}_v{get_version()}.nc"
    duration_path = os.path.join(output_dir, duration_fname)
    if os.path.exists(duration_path) and os.path.exists(weighted_frost_path):
        return weighted_frost_path, weighted_frost_fname, duration_path, duration_fname

    ds_lst, ds_cn = lst_cn_fetcher.fetch_lst_cn_pair(
        cn_data, lst_data, cn_file, lst_file, xarray=True
    )
    masked_lst = get_masked_lst(ds_lst, ds_cn)

    weighted_frost, duration = process_daily_frost_duration(masked_lst, frost_threshold, duration_threshold)

    if weighted_frost is None or duration is None:
        logger.info(f"Skipping pair due to timestamp mismatch")
        return None
    try:
        weighted_frost.load()
        encoding = default_cf_encodings(origin_time)
        encoding.update({
            'frost_hours': {'dtype': 'float32', 'zlib': True, 'complevel': 4, "_FillValue": _DEFAULT_FILL_VALUE}
        })
        weighted_frost.to_netcdf(weighted_frost_path, engine="h5netcdf", encoding=encoding)

        duration.load()

        encoding = default_cf_encodings(origin_time)
        encoding.update({
            'duration': {'dtype': 'float32', 'zlib': True, 'complevel': 4, "_FillValue": _DEFAULT_FILL_VALUE}
        })
        duration.to_netcdf(duration_path, engine="h5netcdf", encoding=encoding)
        return weighted_frost_path, weighted_frost_fname, duration_path, duration_fname
    except OSError as e:
        logger.error(
            f"[OSError] File system error while handling min_temp.nc, {origin_time_str}:\n{e}")
        raise
    except ValueError as e:
        logger.error(
            f"[ValueError] Data formatting or encoding error while handling min_temp.nc, {origin_time_str}:\n{e}")
        raise
    except TypeError as e:
        logger.error(
            f"[TypeError] Possibly invalid dtype or encoding structure for min_temp.nc: {e}")
        raise


def process_daily_frost_duration(
        masked_lst: xr.Dataset,
        frost_threshold: float,
        duration_threshold: float
) -> tuple[None, None] | tuple[Dataset, Dataset]:
    """
    Process a block of LST data with CN mask to calculate frost metrics.
    """

    if bool(masked_lst["lst"].isnull().all()) or bool(masked_lst['time'].isnull().all()):
        logger.info("Found masked LST which all values are NaN")
        logger.info(
            "Found masked LST which time dimension is None, potentially caused by date mismatch between LST and CN files")

        return None, None

    logger.info("Processing Frost Hours and Duration")
    frost_mask = masked_lst < frost_threshold
    dt_hour = 60 * 10 / 3600
    weighted_frost = np.abs(masked_lst.where(frost_mask)) * dt_hour
    daily_weighted_frost = weighted_frost.groupby(weighted_frost.time.dt.date).sum(dim='time')
    daily_weighted_frost['date'] = daily_weighted_frost['date'].astype('datetime64[ns]')
    daily_weighted_frost = daily_weighted_frost.rename({"lst": "frost_hours", 'date': 'time'})

    duration_mask = masked_lst < duration_threshold
    duration = duration_mask.astype(float) * dt_hour
    daily_duration = duration.groupby(duration.time.dt.date).sum(dim='time')
    daily_duration['date'] = daily_duration['date'].astype('datetime64[ns]')
    daily_duration = daily_duration.rename({"lst": "duration", 'date': 'time'})

    return daily_weighted_frost, daily_duration


def validate_file_complete(path):
    try:
        import h5py
        with h5py.File(path, "r"):
            return True
    except Exception:
        return False


def add_to(ern, block_ern, adapter):
    space = adapter.Resource(ern)
    space_collection = adapter.Resource(space.prop("collection"))
    if not any(block_ern in item['ern'] for item in space_collection.props()['items']):
        space_collection.perform_action(
            "AddItems",
            {"items": [{"ern": block_ern, "inheritPermissions": True}]},
        )
        print((f"Added {block_ern} to {ern}"))
    else:
        print(f"block already exists in space {ern}")
    pass


def upload_to_eratos(
        eadapter: Adapter,
        filesMap: Dict[str, str],
        metrics_dict: dict,
        year: int,
        block_template: dict,
        dataset_template: dict,
        frost_threshold: Optional[float] = None,
        duration_threshold: Optional[float] = None,
        max_retries: int = 10,
        replace_old_files: bool = False
):
    metrics_name = str(next(iter(metrics_dict.values())))
    metrics_key = str(next(iter(metrics_dict)))
    # create/update eratos blocks and datasets
    threshold_str = (
        f" - threshold {frost_threshold}" if metrics_key == 'frost.hours'
        else f" - threshold {duration_threshold}" if metrics_key == 'duration'
        else ''
    )
    threshold_value = (
        "." + str(frost_threshold) if metrics_key == 'frost.hours'
        else "." + str(duration_threshold) if metrics_key == 'duration'
        else ""
    )

    block_metadata = {}
    for k, v in block_template.items():
        if isinstance(v, str):
            block_metadata[k] = v.format(
                year=year,
                metrics_key=metrics_key,
                threshold_value=threshold_value,
                threshold=threshold_str,
                metrics_key_str=metrics_key.replace('.', '_'),
                metrics_name=metrics_name
            )
        else:
            block_metadata[k] = v

    dataset_ern = block_metadata["primary"]
    block_ern = block_metadata["@id"]
    eadapter.Resource(content=block_metadata).save()

    dataset_metadata = dataset_template
    dataset_metadata["@id"] = dataset_ern
    dataset_metadata["@owner"] = block_ern
    dataset_metadata["name"] = block_metadata["name"]
    dataset_metadata["description"] = block_metadata["description"]
    eadapter.Resource(content=dataset_metadata).save()

    dataset = eadapter.Resource(ern=dataset_ern)
    datasetData: Data = dataset.data()
    retries = 0

    times = datasetData.gapi().get_subset_as_array('time') if datasetData.gapi() else None

    while True:
        fmap = copy.deepcopy(filesMap)
        try:
            if not datasetData.latest():
                logger.info("Pushing objects")

                props = gridded_geotime_netcdf_props(filesMap,
                                                     skipVars="spatial_ref")
                datasetData.push_objects(
                    "ern::node:au-1.e-gn.io",
                    objects=fmap,
                    connector=Data.GRIDDED_V1,
                    connectorProps=props,
                )
            elif not replace_old_files:
                logger.info("Adding objects")
                datasetData.add_objects(
                    "ern::node:au-1.e-gn.io",
                    objects=fmap,
                    connector=Data.GRIDDED_V1,
                    connectorPropsFn=lambda existingProps: gridded_geotime_netcdf_props(
                        fmap,
                        skipVars="spatial_ref",
                        existingProps=existingProps,
                        existing_unlimited_dimension_coords=times
                    ),
                )
            else:
                logger.info("Replacing objects")
                datasetData.replace_objects(
                    "ern::node:au-1.e-gn.io",
                    fmap

                )
            logger.info(f"Pushing metrics {metrics_key} to {dataset_ern}")

        except Exception as e:
            logger.exception("Upload attempt failed with exception: %s", e)
            retries += 1
            if retries == max_retries:
                logger.error(f"max retries of {max_retries} reached")
                raise
            continue
        break


def process_data_into_daily_output(
        config: FrostMetricsDailyConfig,
        secret: dict,
        block_template: dict,
        dataset_template: dict,
        persist_tmp: bool = False
):
    """
    Process the data into daily output.
    """
    print("System memory limit: ", memory_limit())
    cluster = LocalCluster()
    client = cluster.get_client()
    client.wait_for_workers(n_workers=1, timeout=10)

    print("Number of Workers:", len(cluster.workers))
    print("Worker Specs:", cluster.worker_spec)
    print("Scheduler Address:", cluster.scheduler_address)
    print("Dashboard Link:", cluster.dashboard_link)

    logger.info("Initialising eratos adaptor")
    if secret is not None:
        creds = eratos.creds.AccessTokenCreds(**secret)
        if creds is None:
            raise ValueError("Secret must be specified via port")

    adapter = eratos.adapter.Adapter(creds)

    dataset_ern_template = block_template['primary']
    block_ern_template = block_template['@id']

    project_dir = Path(__file__).parent.parent.parent.resolve()
    temp_dir = FakeTempDir(name='tmp_lst_cn', base_path=project_dir) if persist_tmp else tempfile.TemporaryDirectory()
    lst_cn_fetcher = LSTCNFetcher(adapter, download_dir=temp_dir.name)
    target_date = config.target_date
    if target_date:
        target_date_dt = datetime.strptime(target_date, "%Y-%m-%d")
    else:
        target_date_dt = datetime.now()

    start_date_dt = datetime.strptime(config.start_date, "%Y-%m-%d")
    try:
        for year_start, year_end in get_year_ranges(start_date_dt, target_date_dt):
            lst_files, lst_data = lst_cn_fetcher.fetch_lst_resource_for_year(year_start.year)
            cn_files, cn_data = lst_cn_fetcher.fetch_cn_resource_for_year(year_start.year, current_date=target_date_dt)

            missing_days_min_temp, outdated_days_min_temp = get_missing_days(config, dataset_ern_template, "min.temp",
                                                                             adapter=adapter, start_date=year_start,
                                                                             end_date=year_end)
            print(
                f"Found missing days: {missing_days_min_temp} from {year_start} to {year_end} for Minimum Temperature")

            matched_pairs_min_temp_missing = matching_pairs(lst_files, cn_files, missing_days_min_temp)
            td = FakeTempDir('tmp_min_temp', base_path=project_dir) if persist_tmp else tempfile.TemporaryDirectory()
            if len(missing_days_min_temp) > 0 and len(matched_pairs_min_temp_missing) > 0:
                for pair in matched_pairs_min_temp_missing:
                    result = get_min_temp(config, td.name, lst_cn_fetcher, cn_data, lst_data, pair[0], pair[1])
                    if result is None:
                        continue
                    min_temp_path, fname = result
                    min_temp_fmap = {fname: min_temp_path}
                    min_temp_metrics_dict = {'min.temp': 'Minimum Temperature'}
                    upload_to_eratos(adapter, min_temp_fmap, min_temp_metrics_dict, year_start.year, block_template,
                                     dataset_template, max_retries=10)
            else:
                print("No processable missing days for min temp, probably becasue of missing Clearnight masks for dates")

            if config.replace_outdated:
                outdated_days = list(outdated_days_min_temp.keys())
                print(
                    f"Found outdated days: {outdated_days} from {year_start} to {year_end} for Minimum Temperature")
                matched_pairs_min_temp_replace = matching_pairs(lst_files, cn_files, outdated_days)
                for day, pair in zip(outdated_days, matched_pairs_min_temp_replace):
                    result = get_min_temp(config, td.name, lst_cn_fetcher, cn_data, lst_data, pair[0], pair[1])
                    if result is None:
                        continue
                    min_temp_path, fname = result
                    fmap = {outdated_days_min_temp[day]: min_temp_path}
                    upload_to_eratos(adapter, fmap, min_temp_metrics_dict, year_start.year, block_template,
                                     dataset_template,
                                     max_retries=10, replace_old_files=True)
            td.cleanup()
            min_temp_resource_ern = block_ern_template.format(year=year_start.year, metrics_key='min.temp',
                                                              threshold_value='')
            for space_ern in config.spaces:
                add_to(space_ern, min_temp_resource_ern, adapter)

            for frost_threshold, duration_threshold in zip(config.frost_threshold_lst, config.duration_threshold_lst):
                missing_days_duration, outdated_days_duration = get_missing_days(
                    config,
                    dataset_ern_template,
                    "duration",
                    adapter=adapter,
                    start_date=year_start,
                    end_date=year_end,
                    threshold=f".{duration_threshold}",
                )

                print(
                    f"Found missing days: {missing_days_duration} from {year_start} to {year_end} for duration and frost hours")

                print(
                    f"Found outdated days: {outdated_days_duration} from {year_start} to {year_end} for duration and frost hours")

                matched_pairs_duration = matching_pairs(lst_files, cn_files,
                                                        missing_days_duration)
                td = FakeTempDir(
                    f'tmp_duration_{frost_threshold}_{duration_threshold}', base_path=project_dir) if persist_tmp else tempfile.TemporaryDirectory()
                if len(missing_days_duration) > 0 and len(matched_pairs_duration) > 0:
                    for pair in matched_pairs_duration:
                        result = get_frost_hours(config, td.name, lst_cn_fetcher, cn_data, lst_data, pair[0], pair[1],
                                                 frost_threshold, duration_threshold)
                        if result is None:
                            continue
                        weighted_frost_path, weighted_frost_fname, duration_path, duration_fname = result
                        upload_to_eratos(adapter, {weighted_frost_fname: weighted_frost_path},
                                         {'frost.hours': 'Frost Hours'}, year_start.year, block_template,
                                         dataset_template,
                                         frost_threshold, duration_threshold, max_retries=10)
                        upload_to_eratos(adapter, {duration_fname: duration_path}, {'duration': 'Duration'},
                                         year_start.year,
                                         block_template, dataset_template, frost_threshold, duration_threshold,
                                         max_retries=10)
                else:
                    print(
                        "No processable missing days for duration and frost hours, probably because of missing Clearnight masks for dates")
                if config.replace_outdated:
                    outdated_days = list(outdated_days_duration.keys())
                    print(f"Found {len(outdated_days)} outdated days in total for year {year_start.year} for Duration")
                    matched_pairs_duration_replace = matching_pairs(lst_files, cn_files, outdated_days)
                    for day, pair in zip(outdated_days, matched_pairs_duration_replace):
                        result = get_frost_hours(config, td.name, lst_cn_fetcher, cn_data, lst_data, pair[0], pair[1],
                                                 frost_threshold, duration_threshold)
                        if result is None:
                            continue
                        weighted_frost_path, weighted_frost_fname, duration_path, duration_fname = result
                        duration_fmap = {outdated_days_duration[day]: duration_path}
                        # this is extremely hacky and due to the fact that the pairs are grabbed from the duration resource,
                        # not from the frost hours resource
                        frost_hours_fmap = {
                            outdated_days_duration[day].replace('duration', 'frost_hours'): weighted_frost_path}
                        upload_to_eratos(adapter, duration_fmap, {'duration': 'Duration'}, year_start.year,
                                         block_template,
                                         dataset_template, frost_threshold, duration_threshold, max_retries=10,
                                         replace_old_files=True)
                        upload_to_eratos(adapter, frost_hours_fmap, {'frost.hours': 'Frost Hours'}, year_start.year,
                                         block_template, dataset_template, frost_threshold, duration_threshold,
                                         max_retries=10, replace_old_files=True)
                td.cleanup()
                hours_resource_ern = block_ern_template.format(year=year_start.year, metrics_key='frost.hours',
                                                               threshold_value=f".{str(frost_threshold)}")
                duration_resource_ern = block_ern_template.format(year=year_start.year, metrics_key='duration',
                                                                  threshold_value=f".{str(frost_threshold)}")
                for space_ern in config.spaces:
                    add_to(space_ern, hours_resource_ern, adapter)
                    add_to(space_ern, duration_resource_ern, adapter)


    finally:
        logger.info("Completed")
        logger.info("Shutting down cluster")
        client.shutdown()
