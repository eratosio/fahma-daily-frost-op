import concurrent
import logging
import os
import re
import time
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, date
from typing import Optional

import backoff
import pandas as pd
import xarray as xr
from eratos.adapter import Adapter
from eratos.errors import CommError

from .config import FrostMetricsDailyConfig
from .version import get_version

# Configure basic logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    datefmt='%Y-%m-%d %H:%M:%S'
)
logger = logging.getLogger(__name__)
# eg "min_temp_2023-01-01_v1.0.0.nc"
# eg "min_temp_2023-01-01.nc"
pattern = ".*_(\d{4}-\d{2}-\d{2})(?:_v(\d+\.\d+\.\d+))?\.nc"
filename_pattern = re.compile(pattern)
class LSTCNFetcher:
    _LST_ERN = "ern:e-pn.io:resource:csiro.blocks.himawari.lst.2km.24hr.{year}"
    _CN_ERN = "ern:e-pn.io:resource:fahma.blocks.clearnights.lst.masked.2km.{year}.dailyupdate"
    _CN_ERN_V2 = "ern:e-pn.io:resource:fahma.blocks.clearnights.lst.masked.2km.{year}.dailyupdate.v2"
    _CN_ERN_V2_1 = "ern:e-pn.io:resource:fahma.blocks.clearnights.lst.masked.2km.{year}.dailyupdate.v2.1"

    def __init__(self, adapter: Adapter, download_dir: str) -> None:
        self.cn_files = {}
        self.lst_files = {}
        self.adapter = adapter
        self.download_dir = download_dir

    @backoff.on_exception(
        backoff.expo,
        (Exception,),
        max_tries=4,  # 1 initial try + 3 retries
        max_time=300,  # Max 5 minutes total
        jitter=backoff.full_jitter,
        logger=logger,
    )
    def _download_file(self, data, key: str, dest_dir: str) -> str:
        """Download a file with automatic retry on failure.
        
        Args:
            data: Data source to download from
            key: File key/name to download
            dest_dir: Directory to save the downloaded file
            
        Returns:
            Path to the downloaded file
            
        Raises:
            ValueError: If the downloaded file is invalid or corrupted
            Exception: If download fails after maximum retries
        """
        dest_path = os.path.join(dest_dir, key)
        
        # If file exists and is valid, return its path
        if self._is_valid_netcdf(dest_path):
            return dest_path
            
        # Download the file
        logger.info(f"Downloading {key}")
        data.fetch_object(dest=dest_dir, key=key)
        
        # Verify the download
        if not self._is_valid_netcdf(dest_path):
            raise ValueError(f"Downloaded file {key} is invalid or corrupted")
            
        return dest_path
        
    def _is_valid_netcdf(self, filepath: str) -> bool:
        """Check if the file exists and is a valid NetCDF file."""
        try:
            if not os.path.exists(filepath) or os.path.getsize(filepath) == 0:
                return False
            # Try opening the file to verify it's a valid NetCDF
            with xr.open_dataset(filepath, engine='h5netcdf') as ds:
                return True
        except Exception as e:
            logger.warning(f"Invalid NetCDF file {filepath}: {str(e)}")
            try:
                # Clean up invalid file
                os.remove(filepath)
            except OSError:
                pass
            return False

    def _fetch_data_from_ern(self, ern: str):
        resource = self.adapter.Resource(ern)
        data = resource.data()
        files = list(data.list_objects())
        return files, data

    def fetch_lst_cn_pair(
        self, cn_data, lst_data, cn: str, lst: str, xarray: bool = True
    ) -> tuple[str | xr.Dataset, str | xr.Dataset]:
        """Fetch LST and CN file pair with automatic retries and validation.
        
        Args:
            cn_data: Data source for CN file
            lst_data: Data source for LST file
            cn: CN filename
            lst: LST filename
            xarray: If True, return xarray Datasets, else return file paths
            
        Returns:
            Tuple of (lst_data, cn_data) as either file paths or xarray Datasets
        """
        logger.info(f"Fetching files {lst}, {cn}")
        
        # Ensure download directory exists
        os.makedirs(self.download_dir, exist_ok=True)
        
        with ThreadPoolExecutor() as executor:
            # Submit download tasks
            futures = {}
            
            # Handle CN file download
            if not (cn_path := self.cn_files.get(cn, None)):
                cn_path = os.path.join(self.download_dir, cn)
                if not self._is_valid_netcdf(cn_path):
                    future = executor.submit(self._download_file, cn_data, cn, self.download_dir)
                    futures[future] = ('cn', cn)
                else:
                    self.cn_files[cn] = cn_path
            
            # Handle LST file download
            if not (lst_path := self.lst_files.get(lst, None)):
                lst_path = os.path.join(self.download_dir, lst)
                if not self._is_valid_netcdf(lst_path):
                    future = executor.submit(self._download_file, lst_data, lst, self.download_dir)
                    futures[future] = ('type', lst)
                else:
                    self.lst_files[lst] = lst_path
            
            # Process completed downloads
            for future in concurrent.futures.as_completed(futures):
                file_type, filename = futures[future]
                try:
                    downloaded_path = future.result()
                    if file_type == 'cn':
                        self.cn_files[cn] = downloaded_path
                    else:
                        self.lst_files[lst] = downloaded_path
                except Exception as e:
                    logger.error(f"Failed to download {filename}: {str(e)}")
                    raise

            if futures:
                concurrent.futures.wait(futures)
                for fut in futures:
                    # get any exception
                    fut.result()

        if futures:
            max_retries = 10
            for _ in range(max_retries):
                if all(os.path.exists(p) for p in [lst_path, cn_path]):
                    break
                time.sleep(0.5)
            else:
                raise FileNotFoundError(
                    f"File not complete after {max_retries} retries: {lst_path}, {cn_path}"
                )

        if xarray:

            ds_lst = xr.open_dataset(lst_path, drop_variables="spatial_ref",
                                    engine="h5netcdf",
                                    chunks="auto")
            ds_cn = xr.open_dataset(cn_path, drop_variables="spatial_ref", engine="h5netcdf", chunks="auto")
            return ds_lst, ds_cn
        else:
            return lst_path, cn_path

    def fetch_lst_resource_for_year(self, year:int):
        lst_ern = self._LST_ERN.format(year=year)

        # cache?
        lst_files, lst_data = self._fetch_data_from_ern(lst_ern)

        return lst_files, lst_data

    def fetch_cn_resource_for_year(self, year: int, current_date: datetime):
        cn_ern = self._CN_ERN.format(year=year)
        cn_ern_v2 = self._CN_ERN_V2.format(year=year)

        # todo: code these magic dates properly
        if year < 2025 or current_date.date() < datetime(2025, 6, 10).date():
            cn_files, cn_data = self._fetch_data_from_ern(cn_ern)

        elif year >= 2025 and current_date.date() <= datetime(2025, 8, 18).date():
            cn_files, cn_data = self._fetch_data_from_ern(cn_ern_v2)
        elif year >= 2025 and current_date.date() > datetime(2025, 8, 18).date():
            cn_files, cn_data = self._fetch_data_from_ern(self._CN_ERN_V2_1.format(year=year))
        else:
            raise ValueError(f"Year {year} is invalid!")

        return cn_files, cn_data


def extract_date(filename):
    return datetime.strptime(filename[:8], "%Y%m%d")


def extract_frost_metrics_date(filename):
    date_str = filename_pattern.match(filename).group(1)
    return datetime.strptime(date_str, "%Y-%m-%d")


def default_cf_encodings(origin_time: datetime):

    return {

            'lon': {'dtype': 'float64', 'zlib': True, 'complevel': 4},
            'lat': {'dtype': 'float64', 'zlib': True, 'complevel': 4},
            'time': {'dtype': 'float64',
                        'zlib': True,
                        'complevel': 4,
                        'units': f"days since {origin_time.strftime('%Y-%m-%d %H:%M:%S')}",
                        'calendar': 'proleptic_gregorian'},
    }
    


def get_file_version(f : str):
    return filename_pattern.match(f).group(2)

def get_missing_days(
    config: FrostMetricsDailyConfig,
    ern_template: str,
    metrics_key: str,
    adapter: Adapter,
    start_date: date,
    end_date: date,
    threshold: Optional[str] = "",
):
    """
    Get the missing days for the frost metrics for a year.
    Start and end dates must be in the same year.
    """
    assert start_date.year == end_date.year

    expected_dates = [
        x.to_pydatetime()
        for x in pd.date_range(start_date, end_date)
    ]

    ern = ern_template.format(year=start_date.year, metrics_key=metrics_key, threshold_value=threshold)

    try:
        resource = adapter.Resource(ern)
        data = resource.data()
        files = list(data.list_objects())
    except CommError as e:
        logger.info(f"No files existing files found for ern {ern_template}")
        return list(expected_dates), {}

    existing_dates = {
        extract_frost_metrics_date(f["key"]): {
            "key": f["key"],
            "version": get_file_version(f["key"]),
        }
        for f in files
    }
    
    # Generate all dates for the year

    missing = []
    to_replace = {}

    for dt in expected_dates:
        if dt not in existing_dates:
            missing.append(dt)
        elif current_filename := existing_dates.get(dt):
            if current_filename["version"] != get_version():
                to_replace[dt] = current_filename

    return missing, to_replace


def matching_pairs(lst_files, cn_files, missing_days):
    """
    Match the files in lst_files and cn_files based on the date in the filename.
    """
    matched_pairs = []
    if missing_days == []:
        return matched_pairs
    missing_days_in_year = [d for d in missing_days]

    lst_lookup = {extract_date(f["key"]): f["key"] for f in lst_files}
    cn_lookup = {extract_date(f["key"]): f["key"] for f in cn_files}

    for d in missing_days_in_year:
        if d in lst_lookup and d in cn_lookup:
                matched_pairs.append((cn_lookup[d], lst_lookup[d]))

    return matched_pairs


def get_year_ranges(start_date: date, end_date: date) -> list[tuple[date, date]]:
    years = range(start_date.year, end_date.year + 1)
    ranges = []

    for year in years:
        if year == start_date.year and year == end_date.year:
            # Same year - use both custom dates
            ranges.append((start_date, end_date))
        elif year == start_date.year:
            # First year - start from start_date, end at Dec 31
            ranges.append((start_date, date(year, 12, 31)))
        elif year == end_date.year:
            # Last year - start from Jan 1, end at end_date
            ranges.append((date(year, 1, 1), end_date))
        else:
            # Middle years - full year
            ranges.append((date(year, 1, 1), date(year, 12, 31)))

    return ranges


class FakeTempDir:
    def __init__(self, name="tmp", base_path=None):
        if not base_path:
            self.base_path = os.path.dirname(os.path.abspath(__file__))
        else:
            self.base_path = base_path
        self.name = os.path.join(self.base_path, name)
        os.makedirs(self.name, exist_ok=True)

    def __enter__(self):
        return self
    def __exit__(self, exc_type, exc_val, exc_tb):
        pass
    def cleanup(self):
        pass