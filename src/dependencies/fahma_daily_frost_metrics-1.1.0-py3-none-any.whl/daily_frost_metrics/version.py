import json

VERSION_MAJOR = 1
VERSION_MINOR = 1
VERSION_PATCH = 0

MODEL_ID_PREFIX = "fahma.models.daily.frost.metrics"

def get_model_id_runtime():
    try:
        with open(".build.json", "r") as f:
            dev = json.load(f)["dev"]
            return get_model_id(dev)
    except FileNotFoundError:
        return get_model_id(False)
    except KeyError:
        return get_model_id(False)
    except Exception as e:
        return get_model_id(False)

def get_model_id(dev):
    if dev:
        model_id = f"{MODEL_ID_PREFIX}.v{VERSION_MAJOR}-dev"
    else:
        model_id = f"{MODEL_ID_PREFIX}.v{VERSION_MAJOR}"
    return model_id

def get_version():
    return f"{VERSION_MAJOR}.{VERSION_MINOR}.{VERSION_PATCH}"